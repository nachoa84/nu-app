#!/usr/bin/env bash
set -Eeuo pipefail

MODE="${1:---check}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
MIGRATION="$ROOT/migration-collagen-assets-v1"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/_backup-collagen-30dias-$STAMP"
REPORT="$ROOT/INTEGRACION-COLLAGEN-RESULTADO.txt"

EXPECTED_INDEX_HTML="325c44ff0f7bc5b79f5180f95445a2164e270d7a9b062e1ad1a5c03e2113599d"
EXPECTED_PROGRESS_VIEW_JS="3cad839c62086975976e80c2d3a1cece6c2c17e1f66fcd07dfa2951d3b2c198c"
EXPECTED_SERVICE_WORKER_JS="d8486f934d35d21aaf2ad6db367697896010eaa160afce443e0a036fe74025e6"
EXPECTED_SERVER_JS="6a4b001f2f12a62d6521e5d521ebb17af64975f49b3f5b3bcbb73ae473073684"

usage() {
  cat <<'EOF'
Uso:
  ./integrar-collagen-30dias.sh --check
  ./integrar-collagen-30dias.sh --apply

--check valida archivos, hashes y los 191 recursos sin modificar la app.
--apply crea un backup, incorpora Días 8–30 y ajusta progreso, backend y caché.
EOF
}

case "$MODE" in
  --check|--apply) ;;
  -h|--help) usage; exit 0 ;;
  *) usage; exit 2 ;;
esac

fail() {
  echo
  echo "❌ $*" >&2
  exit 1
}

hash_file() {
  sha256sum "$1" | awk '{print $1}'
}

check_exact_hash() {
  local file="$1"
  local expected="$2"

  [[ -f "$ROOT/$file" ]] || fail "No se encontró $file en la raíz del Remix."

  local actual
  actual="$(hash_file "$ROOT/$file")"

  if [[ "$actual" != "$expected" ]]; then
    echo "Archivo distinto: $file"
    echo "Esperado: $expected"
    echo "Actual:   $actual"
    fail "El proyecto cambió desde el recolector. No se aplicó nada."
  fi

  echo "✓ Versión esperada: $file"
}

echo "Nu App · Integración Collagen+ Días 8–30"
echo "Modo: $MODE"
echo "Raíz: $ROOT"
echo

[[ -d "$PAYLOAD" ]] || fail "No se encontró la carpeta payload junto al script."
[[ -d "$MIGRATION" ]] || fail "No se encontró migration-collagen-assets-v1."
[[ -f "$MIGRATION/nuapp-collagen-30dias-local-v1.json" ]] ||
  fail "Falta nuapp-collagen-30dias-local-v1.json."
[[ -f "$MIGRATION/assets-manifest.json" ]] ||
  fail "Falta assets-manifest.json."

for payload_file in \
  routine-content-collagen-8-30.js \
  progress-view.js \
  service-worker.js \
  server.js \
  index.html
do
  [[ -f "$PAYLOAD/$payload_file" ]] ||
    fail "Falta payload/$payload_file."
done

echo "Validando versión actual del Remix..."
check_exact_hash "index.html" "$EXPECTED_INDEX_HTML"
check_exact_hash "progress-view.js" "$EXPECTED_PROGRESS_VIEW_JS"
check_exact_hash "service-worker.js" "$EXPECTED_SERVICE_WORKER_JS"
check_exact_hash "server.js" "$EXPECTED_SERVER_JS"

echo
echo "Validando sintaxis del parche..."
for file in \
  "$PAYLOAD/routine-content-collagen-8-30.js" \
  "$PAYLOAD/progress-view.js" \
  "$PAYLOAD/service-worker.js" \
  "$PAYLOAD/server.js"
do
  node --check "$file" >/dev/null ||
    fail "Error de sintaxis en $(basename "$file")."
done
echo "✓ Sintaxis JavaScript correcta"

echo
echo "Validando recursos descargados..."
python3 - "$ROOT" <<'PY'
from __future__ import annotations

import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
migration = root / "migration-collagen-assets-v1"
manifest_path = migration / "assets-manifest.json"
local_json_path = migration / "nuapp-collagen-30dias-local-v1.json"

manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
local_data = json.loads(local_json_path.read_text(encoding="utf-8"))

summary = manifest.get("summary") or {}
assets = manifest.get("assets") or []

if int(summary.get("tasks", 0)) != 191:
    raise SystemExit(
        f"El manifiesto informa {summary.get('tasks')} recursos; se esperaban 191."
    )

if int(summary.get("errors", 0)) != 0:
    raise SystemExit(
        f"El manifiesto informa {summary.get('errors')} errores."
    )

paths = []
for day in local_data.get("days", []):
    for message in day.get("messages", []):
        path = message.get("local_path")
        if path:
            paths.append((int(day["day"]), path))

unique_paths = []
seen = set()
for day, path in paths:
    if path in seen:
        continue
    seen.add(path)
    unique_paths.append((day, path))

if len(unique_paths) != 191:
    raise SystemExit(
        f"El JSON local contiene {len(unique_paths)} recursos únicos; se esperaban 191."
    )

missing = []
empty = []
for day, relative in unique_paths:
    source = migration / relative
    if not source.is_file():
        missing.append(relative)
    elif source.stat().st_size <= 0:
        empty.append(relative)

if missing:
    raise SystemExit(
        "Faltan recursos descargados:\n- " + "\n- ".join(missing[:20])
    )

if empty:
    raise SystemExit(
        "Hay recursos vacíos:\n- " + "\n- ".join(empty[:20])
    )

selected = [(day, path) for day, path in unique_paths if day >= 8]
if len(selected) != 144:
    raise SystemExit(
        f"Se detectaron {len(selected)} recursos para Días 8–30; se esperaban 144."
    )

total_bytes = sum((migration / path).stat().st_size for _, path in unique_paths)
selected_bytes = sum((migration / path).stat().st_size for _, path in selected)

print("✓ 191/191 recursos presentes")
print("✓ 144 recursos corresponden a Días 8–30")
print(f"✓ Total descargado: {total_bytes / 1024 / 1024:.1f} MB")
print(f"✓ A integrar: {selected_bytes / 1024 / 1024:.1f} MB")
PY

echo
echo "Validando contenido de Días 8–30..."
node - "$PAYLOAD/routine-content-collagen-8-30.js" <<'NODE'
const fs = require("fs");
const vm = require("vm");

const file = process.argv[2];
const context = { days: {} };
vm.createContext(context);
vm.runInContext(fs.readFileSync(file, "utf8"), context);

const dayNumbers = Object.keys(context.days)
  .map(Number)
  .sort((a, b) => a - b);

if (
  dayNumbers.length !== 23 ||
  dayNumbers[0] !== 8 ||
  dayNumbers[dayNumbers.length - 1] !== 30
) {
  throw new Error(
    `Contenido inválido: ${dayNumbers.length} días, rango ` +
    `${dayNumbers[0]}–${dayNumbers[dayNumbers.length - 1]}`
  );
}

for (let day = 8; day <= 30; day += 1) {
  if (!context.days[day]?.blocks?.length) {
    throw new Error(`Falta contenido para el Día ${day}.`);
  }
}

console.log("✓ Contenido completo: Días 8–30");
NODE

if [[ "$MODE" == "--check" ]]; then
  echo
  echo "✅ VALIDACIÓN COMPLETA"
  echo "No se modificó ningún archivo."
  echo
  echo "Ahora ejecutá:"
  echo "./integrar-collagen-30dias.sh --apply"
  exit 0
fi

echo
echo "Creando backup..."
mkdir -p "$BACKUP"
cp -p \
  "$ROOT/index.html" \
  "$ROOT/progress-view.js" \
  "$ROOT/service-worker.js" \
  "$ROOT/server.js" \
  "$BACKUP/"

if [[ -f "$ROOT/routine-content-collagen-8-30.js" ]]; then
  cp -p "$ROOT/routine-content-collagen-8-30.js" "$BACKUP/"
fi

cat > "$BACKUP/RESTAURAR.sh" <<EOF
#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$ROOT"
BACKUP="$BACKUP"

cp -p "\$BACKUP/index.html" "\$ROOT/index.html"
cp -p "\$BACKUP/progress-view.js" "\$ROOT/progress-view.js"
cp -p "\$BACKUP/service-worker.js" "\$ROOT/service-worker.js"
cp -p "\$BACKUP/server.js" "\$ROOT/server.js"

if [[ -f "\$BACKUP/routine-content-collagen-8-30.js" ]]; then
  cp -p "\$BACKUP/routine-content-collagen-8-30.js" \
    "\$ROOT/routine-content-collagen-8-30.js"
else
  rm -f "\$ROOT/routine-content-collagen-8-30.js"
fi

echo "Restauración terminada. Reiniciá el Remix."
EOF
chmod +x "$BACKUP/RESTAURAR.sh"
echo "✓ Backup: $BACKUP"

echo
echo "Incorporando recursos de Días 8–30..."
python3 - "$ROOT" <<'PY'
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

root = Path(sys.argv[1])
migration = root / "migration-collagen-assets-v1"
local_data = json.loads(
    (migration / "nuapp-collagen-30dias-local-v1.json")
    .read_text(encoding="utf-8")
)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

tasks = []
seen = set()

for day in local_data.get("days", []):
    day_number = int(day["day"])
    if day_number < 8:
        continue

    for message in day.get("messages", []):
        relative = message.get("local_path")
        if not relative or relative in seen:
            continue
        seen.add(relative)
        tasks.append((day_number, relative))

conflicts = []

for day_number, relative in tasks:
    source = migration / relative
    destination = root / relative

    if destination.exists():
        if (
            destination.is_file() and
            destination.stat().st_size == source.stat().st_size and
            sha256(destination) == sha256(source)
        ):
            continue
        conflicts.append(relative)

if conflicts:
    raise SystemExit(
        "Hay archivos existentes diferentes en el destino:\n- " +
        "\n- ".join(conflicts[:30]) +
        "\nNo se reemplazó ninguno."
    )

linked = 0
copied = 0
existing = 0

for day_number, relative in tasks:
    source = migration / relative
    destination = root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists():
        existing += 1
        continue

    try:
        os.link(source, destination)
        linked += 1
    except OSError:
        shutil.copy2(source, destination)
        copied += 1

for _, relative in tasks:
    source = migration / relative
    destination = root / relative

    if not destination.is_file():
        raise SystemExit(f"No se creó {relative}.")

    if destination.stat().st_size != source.stat().st_size:
        raise SystemExit(f"Tamaño distinto después de integrar {relative}.")

print(f"✓ Hardlinks creados: {linked}")
print(f"✓ Copias físicas creadas: {copied}")
print(f"✓ Ya existentes e idénticos: {existing}")
print(f"✓ Total verificado: {len(tasks)}")
PY

echo
echo "Aplicando código..."
install -m 0644 \
  "$PAYLOAD/routine-content-collagen-8-30.js" \
  "$ROOT/routine-content-collagen-8-30.js"
install -m 0644 "$PAYLOAD/progress-view.js" "$ROOT/progress-view.js"
install -m 0644 "$PAYLOAD/service-worker.js" "$ROOT/service-worker.js"
install -m 0644 "$PAYLOAD/server.js" "$ROOT/server.js"
install -m 0644 "$PAYLOAD/index.html" "$ROOT/index.html"

echo "✓ Código aplicado"

echo
echo "Verificación final..."
for file in \
  "$ROOT/routine-content.js" \
  "$ROOT/routine-content-collagen-8-30.js" \
  "$ROOT/progress-view.js" \
  "$ROOT/service-worker.js" \
  "$ROOT/server.js"
do
  node --check "$file" >/dev/null ||
    fail "Falló la sintaxis final en $(basename "$file")."
done

node - "$ROOT/routine-content.js" "$ROOT/routine-content-collagen-8-30.js" <<'NODE'
const fs = require("fs");
const vm = require("vm");

const base = fs.readFileSync(process.argv[2], "utf8");
const addon = fs.readFileSync(process.argv[3], "utf8");

const context = {};
vm.createContext(context);
vm.runInContext(
  `${base}\n${addon}\nglobalThis.__days = days;`,
  context
);

const keys = Object.keys(context.__days)
  .map(Number)
  .sort((a, b) => a - b);

if (
  keys.length !== 30 ||
  keys[0] !== 1 ||
  keys[keys.length - 1] !== 30
) {
  throw new Error(
    `La rutina final tiene ${keys.length} días: ` +
    `${keys[0]}–${keys[keys.length - 1]}`
  );
}

console.log("✓ Rutina final: Días 1–30");
NODE

FINAL_COUNT="$(
  find "$ROOT/assets/collagen" -type f 2>/dev/null | wc -l | tr -d ' '
)"

cat > "$REPORT" <<EOF
INTEGRACIÓN COLLAGEN+ DÍAS 8–30
Fecha: $(date -Iseconds)

Resultado:
- Días actuales 1–7 preservados.
- Días 8–30 incorporados.
- 144 recursos nuevos vinculados/verificados.
- Progreso habilitado dinámicamente hasta Día 30.
- Backend configurado con MAX_DAY 30 por defecto.
- Videos fuera del precache masivo.
- Carpeta de migración bloqueada para acceso público.
- Archivos dentro de assets/collagen: $FINAL_COUNT

Backup:
$BACKUP

Restauración:
$BACKUP/RESTAURAR.sh
EOF

echo
echo "✅ INTEGRACIÓN TERMINADA"
echo "Días disponibles en código: 1–30"
echo "Recursos en assets/collagen: $FINAL_COUNT"
echo "Backup: $BACKUP"
echo "Reporte: $REPORT"
echo
echo "Ahora reiniciá el Remix y verificá /api/health."
