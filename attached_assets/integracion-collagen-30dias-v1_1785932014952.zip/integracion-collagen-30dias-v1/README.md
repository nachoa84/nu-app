# Integración Collagen+ Días 8–30 · Nu App

Este paquete fue generado a partir de los archivos recolectados del Remix y de
la exportación completa de ManyChat.

## Qué hace

- Preserva sin cambios los Días 1–7 actuales.
- Agrega los Días 8–30 en un archivo separado.
- Vincula 144 recursos recuperados correspondientes a Días 8–30.
- Conserva la carpeta de migración y no elimina materiales existentes.
- Habilita dinámicamente las cuatro semanas según `currentDay`.
- Cambia el máximo predeterminado del backend de 7 a 30 días.
- Evita el precache masivo de videos.
- Crea un backup restaurable antes de modificar código.
- Bloquea el acceso público a la carpeta de migración.

## Archivos que modifica

- `index.html`
- `progress-view.js`
- `service-worker.js`
- `server.js`

## Archivo nuevo

- `routine-content-collagen-8-30.js`

## Recursos

Los Días 8–30 usan:

```text
assets/collagen/day-08/
...
assets/collagen/day-30/
```

El instalador intenta crear hardlinks desde la carpeta de migración para no
duplicar aproximadamente 272 MB. Si el sistema no los admite, copia los
archivos. Nunca reemplaza un archivo diferente que ya exista.

## Uso

Subí el ZIP a la raíz del Remix y ejecutá:

```bash
rm -rf integracion-collagen-30dias-v1
unzip -o integracion-collagen-30dias-v1.zip -d integracion-collagen-30dias-v1
chmod +x integracion-collagen-30dias-v1/integrar-collagen-30dias.sh
./integracion-collagen-30dias-v1/integrar-collagen-30dias.sh --check
```

Si la validación termina correctamente:

```bash
./integracion-collagen-30dias-v1/integrar-collagen-30dias.sh --apply
```

Después reiniciá el Remix y verificá:

```bash
curl -s http://127.0.0.1:3000/api/health
```

Debe informar `"maxDay":30`.

## Restauración

El instalador crea una carpeta como:

```text
_backup-collagen-30dias-YYYYMMDD-HHMMSS/
```

Para volver al código anterior:

```bash
./_backup-collagen-30dias-YYYYMMDD-HHMMSS/RESTAURAR.sh
```

Los recursos nuevos quedan en `assets/collagen`, pero al restaurar dejan de
estar referenciados por la aplicación. No se borra ningún material.
