#!/usr/bin/env python3
"""
Descarga los recursos de Collagen+ extraídos de ManyChat.

- Solo usa la biblioteca estándar de Python.
- Reanuda descargas parciales.
- No modifica Nu App.
- Genera manifiesto, auditoría y JSON con rutas locales.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import mimetypes
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

VERSION = "1.0.0"
DEFAULT_INPUT = "nuapp-collagen-30dias-staging-v1.json"
DEFAULT_OUTPUT = "migration-collagen-assets-v1"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 Chrome/150 Safari/537.36"
)

MIME_EXTENSIONS = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
    "video/mp4": ".mp4",
    "video/quicktime": ".mov",
    "video/webm": ".webm",
    "application/pdf": ".pdf",
    "application/zip": ".zip",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.ms-powerpoint": ".ppt",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
}

@dataclass(frozen=True)
class AssetTask:
    day: int
    asset_index: int
    kind: str
    source_url: str
    source_title: str | None
    expected_mime: str | None
    relative_path: str

@dataclass
class DownloadResult:
    day: int
    asset_index: int
    kind: str
    source_url: str
    relative_path: str
    status: str
    bytes: int = 0
    sha256: str | None = None
    content_type: str | None = None
    attempts: int = 0
    error: str | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Descarga los recursos Collagen+ y crea un paquete local."
    )
    parser.add_argument(
        "--input",
        default=DEFAULT_INPUT,
        help=f"JSON normalizado de entrada. Por defecto: {DEFAULT_INPUT}",
    )
    parser.add_argument(
        "--output",
        default=DEFAULT_OUTPUT,
        help=f"Carpeta de salida. Por defecto: {DEFAULT_OUTPUT}",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=0,
        help="Descargar solo los primeros N recursos. 0 = todos.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=3,
        help="Descargas simultáneas. Recomendado: 2 a 4.",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=4,
        help="Intentos máximos por archivo.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=90,
        help="Timeout de red por solicitud, en segundos.",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Volver a descargar archivos ya completos.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Crear inventario sin descargar archivos.",
    )
    return parser.parse_args()


def sanitize_filename(value: str) -> str:
    value = value.strip().replace("\\", "-").replace("/", "-")
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value)
    value = re.sub(r"-{2,}", "-", value).strip("-._")
    return value or "archivo"


def extension_from_task(
    source_url: str,
    source_title: str | None,
    expected_mime: str | None,
    kind: str,
) -> str:
    candidates: list[str] = []

    if source_title:
        candidates.append(Path(source_title).suffix.lower())

    try:
        url_path = urllib.parse.urlparse(source_url).path
        candidates.append(Path(url_path).suffix.lower())
    except Exception:
        pass

    for extension in candidates:
        if extension and 1 < len(extension) <= 8:
            return ".jpg" if extension == ".jpeg" else extension

    normalized_mime = (expected_mime or "").split(";")[0].strip().lower()
    if normalized_mime in MIME_EXTENSIONS:
        return MIME_EXTENSIONS[normalized_mime]

    guessed = mimetypes.guess_extension(normalized_mime) if normalized_mime else None
    if guessed:
        return ".jpg" if guessed == ".jpe" else guessed

    return ".jpg" if kind == "image" else ".bin"


def asset_kind(message: dict[str, Any]) -> str:
    attachment_type = message.get("attachment_type")
    mime = str(message.get("mime") or "").lower()
    title = str(message.get("title") or "").lower()
    url = str(message.get("source_url") or "").lower()

    if attachment_type == "image":
        return "image"
    if mime.startswith("video/") or title.endswith((".mp4", ".mov", ".webm", ".m4v")):
        return "video"
    if url.endswith((".mp4", ".mov", ".webm", ".m4v")):
        return "video"
    if mime == "application/pdf" or title.endswith(".pdf") or url.endswith(".pdf"):
        return "document"
    return "file"


def build_tasks(data: dict[str, Any]) -> tuple[list[AssetTask], dict[str, str]]:
    tasks: list[AssetTask] = []
    url_to_relative: dict[str, str] = {}

    for day_entry in data.get("days", []):
        day = int(day_entry["day"])
        asset_index = 0

        for message in day_entry.get("messages", []):
            if message.get("type") != "attachment":
                continue

            source_url = message.get("source_url")
            if not source_url:
                continue

            asset_index += 1
            kind = asset_kind(message)
            extension = extension_from_task(
                source_url=source_url,
                source_title=message.get("title"),
                expected_mime=message.get("mime"),
                kind=kind,
            )

            kind_label = {
                "image": "IMAGE",
                "video": "VIDEO",
                "document": "DOCUMENT",
                "file": "FILE",
            }[kind]

            filename = f"D{day:02d}_{asset_index:03d}_{kind_label}{extension}"
            relative_path = (
                Path("assets")
                / "collagen"
                / f"day-{day:02d}"
                / filename
            ).as_posix()

            task = AssetTask(
                day=day,
                asset_index=asset_index,
                kind=kind,
                source_url=source_url,
                source_title=message.get("title"),
                expected_mime=message.get("mime"),
                relative_path=relative_path,
            )
            tasks.append(task)
            url_to_relative[source_url] = relative_path

    return tasks, url_to_relative


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_one(
    task: AssetTask,
    output_dir: Path,
    retries: int,
    timeout: int,
    overwrite: bool,
) -> DownloadResult:
    destination = output_dir / task.relative_path
    partial = destination.with_suffix(destination.suffix + ".part")
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists() and destination.stat().st_size > 0 and not overwrite:
        return DownloadResult(
            day=task.day,
            asset_index=task.asset_index,
            kind=task.kind,
            source_url=task.source_url,
            relative_path=task.relative_path,
            status="skipped_existing",
            bytes=destination.stat().st_size,
            sha256=sha256_file(destination),
            attempts=0,
        )

    if overwrite:
        destination.unlink(missing_ok=True)
        partial.unlink(missing_ok=True)

    last_error: str | None = None

    for attempt in range(1, retries + 1):
        resume_at = partial.stat().st_size if partial.exists() else 0
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "*/*",
        }
        if resume_at > 0:
            headers["Range"] = f"bytes={resume_at}-"

        request = urllib.request.Request(task.source_url, headers=headers)

        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                status = getattr(response, "status", 200)
                content_type = response.headers.get_content_type()

                append = resume_at > 0 and status == 206
                mode = "ab" if append else "wb"

                if resume_at > 0 and not append:
                    resume_at = 0

                with partial.open(mode) as handle:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        handle.write(chunk)

            if not partial.exists() or partial.stat().st_size == 0:
                raise RuntimeError("El servidor devolvió un archivo vacío.")

            os.replace(partial, destination)

            return DownloadResult(
                day=task.day,
                asset_index=task.asset_index,
                kind=task.kind,
                source_url=task.source_url,
                relative_path=task.relative_path,
                status="downloaded",
                bytes=destination.stat().st_size,
                sha256=sha256_file(destination),
                content_type=content_type,
                attempts=attempt,
            )

        except (
            urllib.error.HTTPError,
            urllib.error.URLError,
            TimeoutError,
            ConnectionError,
            OSError,
            RuntimeError,
        ) as error:
            last_error = f"{type(error).__name__}: {error}"

            if isinstance(error, urllib.error.HTTPError) and error.code in {401, 403, 404}:
                break

            if attempt < retries:
                time.sleep(min(10, 1.5 ** attempt))

    return DownloadResult(
        day=task.day,
        asset_index=task.asset_index,
        kind=task.kind,
        source_url=task.source_url,
        relative_path=task.relative_path,
        status="error",
        attempts=retries,
        error=last_error or "Error desconocido",
    )


def update_local_json(
    data: dict[str, Any],
    url_to_relative: dict[str, str],
) -> dict[str, Any]:
    cloned = json.loads(json.dumps(data, ensure_ascii=False))
    cloned["format"] = "nuapp-collagen-local"
    cloned["version"] = "1.0"
    cloned.setdefault("migration", {})
    cloned["migration"] = {
        "assets_root": "assets/collagen",
        "source_urls_preserved": True,
        "ready_for_content_conversion": True,
    }

    for day_entry in cloned.get("days", []):
        for message in day_entry.get("messages", []):
            source_url = message.get("source_url")
            if source_url and source_url in url_to_relative:
                message["local_path"] = url_to_relative[source_url]

    return cloned


def write_report(output_dir: Path, results: list[DownloadResult]) -> None:
    report_path = output_dir / "download-report.csv"
    fields = [
        "day",
        "asset_index",
        "kind",
        "status",
        "bytes",
        "sha256",
        "content_type",
        "attempts",
        "relative_path",
        "source_url",
        "error",
    ]

    with report_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for result in sorted(results, key=lambda item: (item.day, item.asset_index)):
            writer.writerow(asdict(result))


def write_manifest(
    output_dir: Path,
    tasks: list[AssetTask],
    results: list[DownloadResult],
) -> None:
    by_url = {result.source_url: result for result in results}
    manifest = {
        "format": "nuapp-collagen-assets-manifest",
        "version": VERSION,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "summary": {
            "tasks": len(tasks),
            "downloaded": sum(r.status == "downloaded" for r in results),
            "skipped_existing": sum(r.status == "skipped_existing" for r in results),
            "errors": sum(r.status == "error" for r in results),
            "bytes": sum(r.bytes for r in results),
        },
        "assets": [
            {
                **asdict(task),
                "download": asdict(by_url[task.source_url])
                if task.source_url in by_url
                else None,
            }
            for task in tasks
        ],
    }

    with (output_dir / "assets-manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)


def human_size(value: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    amount = float(value)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.2f} {unit}"
        amount /= 1024
    return f"{value} B"


def main() -> int:
    args = parse_args()

    if args.workers < 1 or args.workers > 8:
        print("❌ --workers debe estar entre 1 y 8.")
        return 2

    input_path = Path(args.input).resolve()
    output_dir = Path(args.output).resolve()

    if not input_path.exists():
        print(f"❌ No existe el archivo de entrada: {input_path}")
        return 2

    try:
        with input_path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as error:
        print(f"❌ No se pudo leer el JSON: {error}")
        return 2

    tasks, url_to_relative = build_tasks(data)

    if args.limit > 0:
        tasks = tasks[: args.limit]
        limited_urls = {task.source_url for task in tasks}
        url_to_relative = {
            url: relative
            for url, relative in url_to_relative.items()
            if url in limited_urls
        }

    output_dir.mkdir(parents=True, exist_ok=True)

    disk = shutil.disk_usage(output_dir)
    print(f"Descargador Collagen+ V{VERSION}")
    print(f"JSON: {input_path.name}")
    print(f"Salida: {output_dir}")
    print(f"Recursos seleccionados: {len(tasks)}")
    print(f"Espacio libre: {human_size(disk.free)}")
    print(f"Descargas simultáneas: {args.workers}")

    local_data = update_local_json(data, url_to_relative)
    with (output_dir / "nuapp-collagen-30dias-local-v1.json").open(
        "w", encoding="utf-8"
    ) as handle:
        json.dump(local_data, handle, ensure_ascii=False, indent=2)

    if args.dry_run:
        empty_results: list[DownloadResult] = []
        write_manifest(output_dir, tasks, empty_results)
        print("✅ Inventario creado. No se descargaron archivos (--dry-run).")
        return 0

    results: list[DownloadResult] = []
    completed = 0

    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        future_map = {
            executor.submit(
                download_one,
                task,
                output_dir,
                args.retries,
                args.timeout,
                args.overwrite,
            ): task
            for task in tasks
        }

        for future in as_completed(future_map):
            task = future_map[future]
            try:
                result = future.result()
            except Exception as error:
                result = DownloadResult(
                    day=task.day,
                    asset_index=task.asset_index,
                    kind=task.kind,
                    source_url=task.source_url,
                    relative_path=task.relative_path,
                    status="error",
                    error=f"Error no controlado: {error}",
                )

            results.append(result)
            completed += 1

            marker = {
                "downloaded": "✅",
                "skipped_existing": "↪️",
                "error": "❌",
            }.get(result.status, "•")

            detail = (
                human_size(result.bytes)
                if result.status != "error"
                else result.error
            )
            print(
                f"[{completed:03d}/{len(tasks):03d}] {marker} "
                f"Día {result.day:02d} · {result.kind} · {detail}",
                flush=True,
            )

    write_report(output_dir, results)
    write_manifest(output_dir, tasks, results)

    errors = [result for result in results if result.status == "error"]
    total_bytes = sum(result.bytes for result in results)

    print()
    print("RESUMEN")
    print(f"- Descargados: {sum(r.status == 'downloaded' for r in results)}")
    print(f"- Ya existentes: {sum(r.status == 'skipped_existing' for r in results)}")
    print(f"- Errores: {len(errors)}")
    print(f"- Tamaño registrado: {human_size(total_bytes)}")
    print(f"- Reporte: {output_dir / 'download-report.csv'}")
    print(f"- Manifiesto: {output_dir / 'assets-manifest.json'}")
    print(
        f"- JSON local: "
        f"{output_dir / 'nuapp-collagen-30dias-local-v1.json'}"
    )

    if errors:
        print()
        print(
            "⚠️ Hubo errores. Ejecutá el mismo comando nuevamente: "
            "el proceso retomará únicamente lo pendiente."
        )
        return 1

    print()
    print("✅ Descarga completa y validada.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
