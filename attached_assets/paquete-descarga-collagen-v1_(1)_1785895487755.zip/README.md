# Paquete de descarga Collagen+ · V1

Este paquete descarga los recursos recuperados de ManyChat sin modificar Nu App.

## Contenido

- `descargar-collagen-assets.py`
- `nuapp-collagen-30dias-staging-v1.json`
- `COMANDOS-RAPIDOS.txt`

## Qué descargará

- 128 imágenes
- 62 videos
- 1 documento
- Total: 191 recursos

Los archivos quedan organizados así:

```text
migration-collagen-assets-v1/
├── assets/
│   └── collagen/
│       ├── day-01/
│       ├── day-02/
│       └── ...
├── assets-manifest.json
├── download-report.csv
└── nuapp-collagen-30dias-local-v1.json
```

## Seguridad

- No modifica `routine-content.js`.
- No reemplaza los días existentes.
- No toca PostgreSQL, el backend ni el Service Worker.
- Puede reanudarse si se corta.
- Conserva las URLs de origen para auditoría.

## Aplicación en Replit

1. Trabajá dentro de la copia Remix.
2. Subí el ZIP a la raíz del proyecto.
3. Abrí Shell.
4. Ejecutá los comandos de `COMANDOS-RAPIDOS.txt`.

Primero se prueban cinco recursos. Luego se ejecuta la descarga completa.

## Importante

No muevas todavía la carpeta `assets/collagen` al proyecto activo. Cuando la
descarga termine, revisaremos el manifiesto y generaremos el parche exacto para
`routine-content.js` y la estrategia de caché de videos.
