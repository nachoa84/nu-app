NU APP · GUÍA DE INICIO NATIVA · PROTOTIPO V1
================================================

OBJETIVO
- Integrar la Guía de inicio dentro de Nu App sin iframe ni apertura de otra web.
- Mantener Inicio · Favoritos · Bot como navegación principal.
- Mostrar la Guía como una tarjeta dentro de Mis rutinas.

QUÉ INCLUYE
- Tarjeta Guía de inicio en Home.
- Vista interna nativa con 9 etapas.
- Contenido y enlaces de la Guía de inicio actual.
- Progreso individual guardado temporalmente en localStorage.
- Pantallas de índice y detalle.
- Botón para completar o volver a dejar pendiente cada etapa.
- Horarios de llamadas, Zoom y galería de comunidad.
- Cache del Service Worker actualizado para los nuevos archivos.

QUÉ NO MODIFICA
- Backend V62A.
- PostgreSQL ni schema.sql.
- Lógica de días de las rutinas.
- Push notifications.
- Favoritos.
- Bot.
- Onboarding.

ARCHIVOS NUEVOS
- guide.css
- guide-content.js
- guide-view.js
- assets/guide/*

ARCHIVOS MODIFICADOS
- index.html
- ui-core.js
- service-worker.js

INSTALACIÓN EN UNA COPIA DE REPLIT
1. Hacer una copia o checkpoint del Replit actual.
2. Subir este ZIP a la raíz del proyecto.
3. Ejecutar:

   unzip -o nu-app-guia-nativa-prototipo-v1-patch.zip

4. Reiniciar el Repl.
5. Abrir la app agregando temporalmente ?preview=1 si se desea probar sin afectar el avance real.
6. En caso de cache viejo, cerrar y volver a abrir la PWA o borrar los datos del sitio.

ROLLBACK
- Restaurar index.html, ui-core.js y service-worker.js desde el checkpoint.
- Eliminar guide.css, guide-content.js, guide-view.js y assets/guide.

NOTA
Este prototipo usa localStorage con la clave nuappGuideProgressV1. Cuando se apruebe la experiencia, el progreso puede migrarse al backend por usuario.
